<?php $this->beginContent('/layouts/main'); ?>
<div class="container">
	<div class="span-18" style="width:100%">
		<div id="content">
			<?php echo $content; ?>
		</div><!-- content -->
	</div>
</div>
<?php $this->endContent(); ?>