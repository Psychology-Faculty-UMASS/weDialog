<div class="footer">
    <div class="copy" style="width:99%;">
    &copy; Copyright 2016. wedialog. All Rights Reserved
        <div style="float: right;">
            <a target="_blank" title="Web Analytics" href="http://clicky.com/100821538"><img alt="Web Analytics" src="//static.getclicky.com/media/links/badge.gif" border="0" /></a>
            <script src="//static.getclicky.com/js" type="text/javascript"></script>
            <script type="text/javascript">try{ clicky.init(100821538); }catch(e){}</script>
            <noscript><p><img alt="Clicky" width="1" height="1" src="//in.getclicky.com/100821538ns.gif" /></p></noscript>
        </div>    
    </div>
</div>