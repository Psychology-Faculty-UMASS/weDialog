
        <table border="2" cellpadding="0" cellspacing="0" height="100%" width="670" style="background-color:#EEEEEE;">

                <tr >
                    
                    <td >
                                      Welcome,<br />Thank you.<br />Below is your Username and Password.<br />Email:<?php echo $forgotpasswordmodel->email;?><br />Username:<?php echo $forgotpasswordmodel->username;?><br />Password:<?php echo $forgotpasswordmodel->password;?><br /><br /><br />Thankyou<br/> From Sigma Topic

                    </td>
                </tr>
         </table>
 		        