<center>
  <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
    <tr>
      <td style="background-color:#ffffff;" align="center" valign="top">
        <table border="0" cellpadding="0" cellspacing="0" height="100%" width="670">
          <tr>
            <td align="left" valign="top" style="border-bottom:1px solid #CBCBCB; background: url('<?php echo Yii::app()->createAbsoluteUrl('/images/header-main-bg.png'); ?>') repeat-x scroll center top transparent;height: 70px;background-color: #3c1b85;">
               
                      <a href="<?php echo Yii::app()->createAbsoluteUrl('/');?>"  target="_blank"  title=""><img src="<?php echo Yii::app()->createAbsoluteUrl('/images/logo.png'); ?>" alt="" style="display:block;" border="0" /></a>
                     
                    
              
            </td>
          </tr>
         