<?php echo $this->renderPartial('../emailTemplatespage/email_header'); ?>
<tr>
    <td align="left" style="background-color: #EEEEEE;height: 350px;padding-left: 10px;"><?php echo $content;?></td>
</tr>


<?php echo $this->renderPartial('../emailTemplatespage/email_footer'); ?>  