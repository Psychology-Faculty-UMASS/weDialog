<tr>
            <td align="left" valign="top" height="1"><img src="<?php echo Yii::app()->createAbsoluteUrl('/images/footer_bg.gif'); ?>" width="670" height="1" alt="" style="display:block;" border="0"/></td>
          </tr>
          <tr>
            <td align="left" valign="top">
             <table width="100%" border="0" cellspacing="0" cellpadding="0" style="font-family: 'Lucida Sans Unicode','Lucida Grande',sans-serif; border-bottom:1px solid #CBCBCB; background: url('<?php echo Yii::app()->createAbsoluteUrl('/images/footer_bg.jpg'); ?>') repeat-x scroll center top transparent;height: 70px;font-size:12px;color:#FCDB8A">
    <tr>       
        <td height="58" align="center" valign="middle" class="footer-center-text">&copy; Copyright 2016. wedialog. All Rights Reserved</td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</center>
