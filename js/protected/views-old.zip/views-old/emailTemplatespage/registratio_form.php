
        <table border="2" cellpadding="0" cellspacing="0" height="100%" width="670" style="background-color:#EEEEEE;">

                <!--<tr style="vertical-align: top;">
                    <td style="padding-left: 10px;vertical-align: top;">
                     <a href="< ?php echo Yii::app()->createAbsoluteUrl('/');?>"  target="_blank"  title=""><img src="<?php echo Yii::app()->createAbsoluteUrl('/images/logo.png'); ?>" alt="" style="display:block;" border="0" /></a>
                                 
                    </td>
                </tr>-->
                <tr >
                    
                    <td >
                                      Welcome,<br />Thank you for registering. Please click the following link to confirm you registration:<br />Link:<?php echo $confirm_link?><br /><br /><br />Below is your Username and Password.<br />Email:<?php echo $model->email?><br />Username:<?php echo $model->username?><br />Password:<?php echo $model->password?><br /><br /><br />Thankyou<br/> From Sigma Topic

                    </td>
                </tr>
         </table>
 		        